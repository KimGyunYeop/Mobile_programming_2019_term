package com.example.myudong;

public class joininfo {
}
